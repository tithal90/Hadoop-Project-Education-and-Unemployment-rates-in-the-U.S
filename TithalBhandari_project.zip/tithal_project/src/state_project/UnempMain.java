package state_project;

import java.io.IOException;



import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;

public class UnempMain {

  public static void main(String[] args) throws IOException {
	  
	  
	  /*Provides access to configuration parameters*/
	  Configuration conf1 = new Configuration();
	  /*Creating Filesystem object with the configuration*/
	  FileSystem fs = FileSystem.get(conf1);
	  /*Check if output path (args[1])exist or not*/
	  if(fs.exists(new Path(args[1]))){
	     /*If exist delete the output path*/
	     fs.delete(new Path(args[1]),true);
	  }
	  
	  JobConf conf = new JobConf(UnempMain.class);
	  
	  
	  /* Unemployment- use unemp.csv as an input */ 
	  /*
	  	conf.setOutputKeyClass(Text.class);
	    conf.setOutputValueClass(Text.class);
	    conf.setMapOutputKeyClass(Text.class);
	    conf.setMapOutputValueClass(Text.class);
	    conf.setMapperClass(UnempMapper.class);
	    //conf.setReducerClass(UnempReducer.class);*/
	    
	  /* Education- use edu.csv as an input*/
	    /*
		conf.setOutputKeyClass(Text.class);
	    conf.setOutputValueClass(Text.class);
	    conf.setMapOutputKeyClass(Text.class);
	    conf.setMapOutputValueClass(Text.class);
	    conf.setMapperClass(EducationMapper.class);
	    //conf.setReducerClass(EducationReducer.class);*/
	    
	  /* FinalMain-use Final_eduunemp.csv as an input */
	   
	    conf.setOutputKeyClass(Text.class);
	    conf.setOutputValueClass(Text.class);
	    conf.setMapOutputKeyClass(Text.class);
	    conf.setMapOutputValueClass(Text.class);
	    conf.setMapperClass(FinalMapper.class);
	    conf.setReducerClass(FinalReducer.class);
	  
	  

	    FileInputFormat.addInputPath(conf, new Path(args[0]));
	    FileOutputFormat.setOutputPath(conf, new Path(args[1]));
	    JobClient.runJob(conf);
	    

	    
	  }
  
  
}
