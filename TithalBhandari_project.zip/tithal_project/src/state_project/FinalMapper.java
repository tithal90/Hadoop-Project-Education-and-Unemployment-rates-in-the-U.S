package state_project;
import java.io.IOException;
import java.io.StringReader;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

import com.opencsv.CSVReader;


public class FinalMapper extends MapReduceBase
implements Mapper<LongWritable, Text, Text, Text> {


private Text edu = new Text();
private Text unemp = new Text();
private Text state = new Text();
private Text county = new Text();


public void map(LongWritable key, Text value,
                OutputCollector<Text, Text> output,
                Reporter reporter) throws IOException {
  String line = value.toString();
  CSVReader R = new CSVReader(new StringReader(line));
  String[] ParsedLine = R.readNext();
  R.close();
 
 
  state.set(ParsedLine[0].trim());
  county.set(ParsedLine[1].trim());
  unemp.set(ParsedLine[3].trim());
  edu.set(ParsedLine[2].trim());
  
  boolean skip = false;
  if (unemp.toString().equals("")||edu.toString().equals(""))
  {
 	 skip = true;
  }else if (unemp.toString().equals(null)||edu.toString().equals(null))
  {
	 	 skip = true;
	  }else if (unemp.toString().matches("")||edu.toString().matches(""))
	  {
		 	 skip = true;
		  }else if (unemp.toString().equals(" ")||edu.toString().equals(" "))
		  {
			 	 skip = true;
			  }
  double edunum = Double.parseDouble(edu.toString());
  double unempnum = Double.parseDouble(unemp.toString());
  if (!skip) {
	  
	  if(edunum>0&unempnum>0)
	  {
		  output.collect(state, new Text("\n"+county + "\t"+ edunum +"\t"+ unempnum +  "\t Group-1")); /*As we put here values, it will show output*/
	  }else if(edunum>0&unempnum<0)
	  {
		  output.collect(state, new Text("\n"+county + "\t"+ edunum +"\t"+ unempnum +"\t Group-2"));  
	  }
	  }else if(edunum<0&unempnum<0 | edunum<0&unempnum>0)
	  {
		  output.collect(state, new Text("\n"+county +"\t"+ edunum +"\t"+ unempnum + "\t Group-3"));
	  }
 	
 	  

  }

  


  
  //output.collect(state, new Text(rate2009 + "\t" + rate2013));
}



