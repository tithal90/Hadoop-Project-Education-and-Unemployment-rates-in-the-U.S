package state_project;
import java.io.IOException;
import java.io.StringReader;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import com.opencsv.CSVReader;


public class UnempMapper extends MapReduceBase
implements Mapper<LongWritable, Text, Text, Text> {

private Text county = new Text();
private Text rate2009 = new Text();
private Text rate2013 = new Text();
private Text state = new Text();

public void map(LongWritable key, Text value,
                OutputCollector<Text, Text> output,
                Reporter reporter) throws IOException {
  String line = value.toString();
  CSVReader R = new CSVReader(new StringReader(line));
  String[] ParsedLine = R.readNext();
  R.close();
 
 
  county.set(ParsedLine[2]);
  rate2009.set(ParsedLine[22].trim());
  rate2013.set(ParsedLine[38].trim());
  state.set(ParsedLine[1]);
  boolean skip = false;
 if (rate2009.toString().equals("")||rate2013.toString().equals(""))
 {
	 skip = true;
 }
	 
 if (!skip) {
	 Double difference = Double.parseDouble(rate2013.toString())-Double.parseDouble(rate2009.toString());
	  double answer = 100*difference/ (Double.parseDouble(rate2009.toString()));
	  output.collect(state, new Text(county + "\t" + answer));

 }


  
  //output.collect(state, new Text(rate2009 + "\t" + rate2013));
}

}
